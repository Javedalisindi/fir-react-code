import React from 'react'
import Navbaar from './components/Navbar'
import Home from './components/Home'
import Signup from './components/Signup';
import Citizen_portal from './Citizen_portal';
import Footer from './components/Footer';

const App = () => {
  return (
    <div className='app'>
      <Navbaar/>
      <Home/>
      
        
    <Footer/>
    </div>
    
  )
}

export default App