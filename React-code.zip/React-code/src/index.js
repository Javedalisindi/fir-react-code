import ReactDOM  from "react-dom";
import App from "./App";
import './index.css'
import {BrowserRouter as Router, Routes, Route} from 'react-router-dom'
import Careers from './components/Home';
import Signup from "./components/Signup";
import File_complaint from './components/file_complaint'
import Citizen_portal from './Citizen_portal'
import View_c_status from './components/View_c_status'
import Admin from '../src/components/Admin/Admin'

ReactDOM.render(
    <Router>
        <Routes>
            <Route path='/' element={<App/>}/>
            <Route path='/home' element={<Careers/>}/>
            <Route path='/signup' element={<Signup/>}/>
            <Route path='/file_complaint' element={<File_complaint/>}/>
            <Route path='/Citizen_portal' element={<Citizen_portal/>}/>
            <Route path='/View_c_status' element={<View_c_status/>}/>
            <Route path='/Admin' element={<Admin/>}/>

        </Routes>
    </Router>,
    
document.querySelector('#root'));