import React from 'react'
import Navbaar from './components/Navbar'
import '../../navbar/src/citizen_portal.css'
import {AiOutlineCaretRight} from 'react-icons/ai';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import { Link } from 'react-router-dom';
import Footer from './components/Footer';
import { useState } from 'react';
import Modal from 'react-bootstrap/Modal';
import {AiFillCheckCircle} from 'react-icons/ai'





const Citizen_portal = () => {
  
  const [show, setShow] = useState(false);

    return (
      
        
        <>
     

        <Navbaar/>
        < div className='container'>
        

         <div class="col-md-3 col-lg-2 sidebar-offcanvas pl-0" id="sidebar" role="navigation" style={{backgroundColor:"#e9ecef"}}>
            <ul class="nav flex-column sticky-top pl-0 pt-5 p-3 mt-3 ">
                <li class="nav-item mb-2 mt-3"><a class="nav-link text-primary" href="#"><h5>Citizen Portal</h5></a></li>
                <li  class="nav-item mb-2 "><Link class="nav-link text-dark" to={'/file_complaint'}><i class="fas fa-user font-weight-bold"></i>  <span className="ml-3"><AiOutlineCaretRight className='dash-icon'/> File A Complaint </span></Link></li>
                <li class="nav-item mb-2 "><a class="nav-link text-dark" href="#"><i class="fas fa-user font-weight-bold"></i> <span className="ml-3"><AiOutlineCaretRight className='dash-icon'/>View FIR</span></a></li>
                <li class="nav-item mb-2 "><Link class="nav-link text-dark" to={'/View_c_status'}><i class="fas fa-user font-weight-bold"></i> <span className="ml-3"><AiOutlineCaretRight className='dash-icon'/>View FIR Status</span></Link></li>
                <li class="nav-item mb-2 "><Link class="nav-link text-dark" to={'/View_c_status'} ><i class="fas fa-user font-weight-bold"></i> <span className="ml-3"><AiOutlineCaretRight className='dash-icon'/>View Complaint Status</span></Link></li>
                <li class="nav-item mb-2 "><a class="nav-link text-dark" href="#"><i class="fas fa-user font-weight-bold"></i> <span className="ml-3"><AiOutlineCaretRight className='dash-icon'/>Reviews</span></a></li>
                <li class="nav-item mb-2 "><a class="nav-link text-dark" href="#"><i class="fas fa-user font-weight-bold"></i> <span className="ml-3"><AiOutlineCaretRight className='dash-icon'/>Response</span></a></li>
                <li class="nav-item mb-2 "><a class="nav-link text-dark" href="#"><i class="fas fa-user font-weight-bold"></i> <span className="ml-3"><AiOutlineCaretRight className='dash-icon'/>Log Out</span></a></li>
                
            </ul>
       </div>
      
       <div className="sig-nup">
     
     <Form>
       <h3>Complaint Details</h3>
     

     <Form.Group className="mb-3" controlId="formBasicEmail">
       <Form.Label>Complainant's Name:</Form.Label>
       <Form.Control type="text" required placeholder="Enter Your Full Name" />
       </Form.Group>

       <Form.Group className="mb-3" controlId="formBasicEmail">
       <Form.Label>Father/Husband's Name:</Form.Label>
       <Form.Control type="text" required placeholder="Enter Your Father's Name" />
       </Form.Group>

       <Form.Group className="mb-3" controlId="formBasicEmail">
       <Form.Label>CNIC No:</Form.Label>
       <Form.Control type="text" required placeholder="Enter Your CNIC" />
     </Form.Group>


     <Form.Group className="mb-3" controlId="formBasicEmail">
       <Form.Label>Cell/Whatsapp No:</Form.Label>
       <Form.Control type="text" required placeholder="Enter Your Mobile No" />
     </Form.Group>
     

       <Form.Group className="mb-3" controlId="formBasicEmail">
       <Form.Label>District:</Form.Label>
       <Form.Control type="text" required placeholder="Enter Your District" />
       </Form.Group>

       <Form.Group className="mb-3" controlId="formBasicEmail">
       <Form.Label>City:</Form.Label>
       <Form.Control type="text" required placeholder="Enter Your City" />
       </Form.Group>

       <Form.Group className="mb-3" controlId="formBasicEmail">
       <Form.Label>Postal Address:</Form.Label>
       <Form.Control type="text" required placeholder="Enter Your Postal Address" />
       </Form.Group>

       <Form.Group className="mb-3" controlId="formBasicEmail">
       <Form.Label>Parmanent Address:</Form.Label>
       <Form.Control type="text" required placeholder="Enter Your Parmanent Address" />
       </Form.Group>
       
       <Form.Group className="mb-3" controlId="formBasicEmail">
       <Form.Label>Zip:</Form.Label>
       <Form.Control type="text" required placeholder="Enter Your Zip Code" />
       </Form.Group>


       <Form.Group className="mb-3" controlId="formBasicEmail">
       <Form.Label>Against Person if any:</Form.Label>
       <Form.Control type="email" required placeholder="Name of person" />
       </Form.Group>
       <Form.Group className="mb-3" controlId="formBasicEmail">
       <Form.Label>CNIC of Accused Person:</Form.Label>
       <Form.Control type="email" required placeholder="Enter CNIC" />
       </Form.Group>
       <Form.Group className="mb-3" controlId="formBasicEmail">
       <Form.Label>Date of Incident:</Form.Label>
       <Form.Control type="date" required placeholder="Enter Complaint Subject" />
       </Form.Group>
       <Form.Group className="mb-3" controlId="formBasicEmail">
       <Form.Label>Place of Incident:</Form.Label>
       <Form.Control type="text" required placeholder="Enter Complaint Subject" />
       </Form.Group>
       <Form.Group className="mb-3" controlId="formBasicEmail">
       <Form.Label>District of Incident:</Form.Label>
       <Form.Control type="text" required placeholder="Enter Complaint Subject" />
       </Form.Group>
       <Form.Group className="mb-3" controlId="formBasicEmail">
       <Form.Label>Already Visited Police Station:</Form.Label>
       <select className="Designation" name="Designation">
       <option value="Citizen">No</option>
       <option value="Police">Yes</option>
     </select>
       </Form.Group>
       <Form.Group className="mb-3" controlId="formBasicEmail">
       <Form.Label>Complaint Subject:</Form.Label>
       <Form.Control type="text" required placeholder="Enter Complaint Subject" />
       </Form.Group>
       <Form.Group className="mb-3" controlId="formBasicEmail">
       <Form.Label>Visit Details ( If Visited ):</Form.Label>
       <Form.Control type="text" required placeholder="Visit Details" />
       </Form.Group>
       <Form.Group className="mb-3" controlId="formBasicEmail">
       <Form.Label>Visit Date ( If Visited ):</Form.Label>
       <Form.Control type="date" required placeholder="Enter Complaint Subject" />
       </Form.Group>

       <Form.Group className="mb-3" controlId="formBasicEmail">
       <Form.Label>Matter of complaint:</Form.Label>
       <Form.Control as="textarea" rows={4} required placeholder="Enter Matter of complaint" />
       </Form.Group>
     
    <Link to={''}><Button  className="mb-5" variant="primary" type="submit" onClick={() => setShow(true)}>
       
    Submit Complaint</Button></Link>
     
   </Form>
   

      <Modal
        show={show}
        onHide={() => setShow(false)}
        dialogClassName="modal-90w"
        aria-labelledby="example-custom-modal-styling-title"
      >
        <Modal.Header closeButton>
          <Modal.Title id="example-custom-modal-styling-title">
            Your complaint has been submited!<AiFillCheckCircle/>
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p>
          Your Complaint has been submitted. Please wait for the confirmation from the police department. You will notified as soon as possisble.
          </p>
          <p>Thank You</p>
        </Modal.Body>
      </Modal>

     </div>
      
       
       </div>
       <Footer/>
       </>
    )
}
 
export default Citizen_portal
