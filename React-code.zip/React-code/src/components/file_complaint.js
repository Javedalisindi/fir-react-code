import React from 'react'
import Navbaar from './Navbar'
import '../../src/citizen_portal.css'
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import { Link } from 'react-router-dom';
import Citizen_portal from '../Citizen_portal'


const file_complaint = () => {
  return (
    <div>
         
         <Citizen_portal/>
         
         {/* <div className="sig-nup">
     
     <Form>
       <h3>Complaint Details</h3>
     

     <Form.Group className="mb-3" controlId="formBasicEmail">
       <Form.Label>Complainant's Name:</Form.Label>
       <Form.Control type="text" required placeholder="Enter Your Full Name" />
       </Form.Group>

       <Form.Group className="mb-3" controlId="formBasicEmail">
       <Form.Label>Father/Husband's Name:</Form.Label>
       <Form.Control type="text" required placeholder="Enter Your Father's Name" />
       </Form.Group>

       <Form.Group className="mb-3" controlId="formBasicEmail">
       <Form.Label>CNIC No:</Form.Label>
       <Form.Control type="text" required placeholder="Enter Your CNIC" />
     </Form.Group>


     <Form.Group className="mb-3" controlId="formBasicEmail">
       <Form.Label>Cell/Whatsapp No:</Form.Label>
       <Form.Control type="text" required placeholder="Enter Your Mobile No" />
     </Form.Group>
     

       <Form.Group className="mb-3" controlId="formBasicEmail">
       <Form.Label>District:</Form.Label>
       <Form.Control type="text" required placeholder="Enter Your District" />
       </Form.Group>

       <Form.Group className="mb-3" controlId="formBasicEmail">
       <Form.Label>City:</Form.Label>
       <Form.Control type="text" required placeholder="Enter Your City" />
       </Form.Group>

       <Form.Group className="mb-3" controlId="formBasicEmail">
       <Form.Label>Postal Address:</Form.Label>
       <Form.Control type="text" required placeholder="Enter Your Postal Address" />
       </Form.Group>

       <Form.Group className="mb-3" controlId="formBasicEmail">
       <Form.Label>Parmanent Address:</Form.Label>
       <Form.Control type="text" required placeholder="Enter Your Parmanent Address" />
       </Form.Group>
       
       <Form.Group className="mb-3" controlId="formBasicEmail">
       <Form.Label>Zip:</Form.Label>
       <Form.Control type="text" required placeholder="Enter Your Zip Code" />
       </Form.Group>


       <Form.Group className="mb-3" controlId="formBasicEmail">
       <Form.Label>Against Person if any:</Form.Label>
       <Form.Control type="email" required placeholder="Name of person" />
       </Form.Group>
       <Form.Group className="mb-3" controlId="formBasicEmail">
       <Form.Label>Date of Incident:</Form.Label>
       <Form.Control type="date" required placeholder="Enter Complaint Subject" />
       </Form.Group>
       <Form.Group className="mb-3" controlId="formBasicEmail">
       <Form.Label>Place of Incident:</Form.Label>
       <Form.Control type="text" required placeholder="Enter Complaint Subject" />
       </Form.Group>
       <Form.Group className="mb-3" controlId="formBasicEmail">
       <Form.Label>District of Incident:</Form.Label>
       <Form.Control type="text" required placeholder="Enter Complaint Subject" />
       </Form.Group>
       <Form.Group className="mb-3" controlId="formBasicEmail">
       <Form.Label>Already Visited Police Station:</Form.Label>
       <select className="Designation" name="Designation">
       <option value="Citizen">No</option>
       <option value="Police">Yes</option>
     </select>
       </Form.Group>
       <Form.Group className="mb-3" controlId="formBasicEmail">
       <Form.Label>Complaint Subject:</Form.Label>
       <Form.Control type="text" required placeholder="Enter Complaint Subject" />
       </Form.Group>
       <Form.Group className="mb-3" controlId="formBasicEmail">
       <Form.Label>Visit Details ( If Visited ):</Form.Label>
       <Form.Control type="text" required placeholder="Visit Details" />
       </Form.Group>
       <Form.Group className="mb-3" controlId="formBasicEmail">
       <Form.Label>Visit Date ( If Visited ):</Form.Label>
       <Form.Control type="date" required placeholder="Enter Complaint Subject" />
       </Form.Group>

       <Form.Group className="mb-3" controlId="formBasicEmail">
       <Form.Label>Matter of complaint:</Form.Label>
       <Form.Control as="textarea" rows={4} required placeholder="Enter Matter of complaint" />
       </Form.Group>
       
       <Form.Group className="mb-3" controlId="formBasicEmail">
       <Form.Label>Attach Document Related to Complaint:</Form.Label>
       <Form.Control type="file" required placeholder="Enter Complaint Subject" />
       </Form.Group>



     
    <Link to={''}><Button  className="mb-5" variant="primary" type="submit">
       
    Submit Complaint</Button></Link>
     
   </Form>
     </div> */}
    </div>
  )
}

export default file_complaint