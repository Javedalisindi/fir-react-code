import React from 'react'
import Navbaar from './Navbar'
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import { Link } from 'react-router-dom';
import Footer from './Footer';

const Signup = () => {
  return (
    <div>
      <Navbaar/>
      <div className="signup">
      <h3>Sign Up / <Link to={'/'}>Log In</Link></h3>
      <Form>
      <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>CNIC:</Form.Label>
        <Form.Control type="text" required placeholder="Enter Your CNIC" />
        <Form.Text className="text-muted">
          We'll never share your CNIC with anyone else.
        </Form.Text>
      </Form.Group>

      <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>Designation:</Form.Label>
        <Form.Control type="text" required placeholder="Enter Your Designation" />
        </Form.Group>

      <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>Full Name:</Form.Label>
        <Form.Control type="text" required placeholder="Enter Your Full Name" />
        </Form.Group>

        <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>District:</Form.Label>
        <Form.Control type="text" required placeholder="Enter Your District" />
        </Form.Group>

        <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>City:</Form.Label>
        <Form.Control type="text" required placeholder="Enter Your City" />
        </Form.Group>

        <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>Postal Address:</Form.Label>
        <Form.Control type="text" required placeholder="Enter Your Postal Address" />
        </Form.Group>

        <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>Parmanent Address:</Form.Label>
        <Form.Control type="text" required placeholder="Enter Your Parmanent Address" />
        </Form.Group>
        
        <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>Zip:</Form.Label>
        <Form.Control type="text" required placeholder="Enter Your Zip Code" />
        </Form.Group>


        <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>Email:</Form.Label>
        <Form.Control type="email" required placeholder="Enter Your email address" />
        </Form.Group>

      <Form.Group className="mb-3" controlId="formBasicPassword">
        <Form.Label>Password</Form.Label>
        <Form.Control type="password" placeholder="Enter Your Password" />
      </Form.Group>

      <Form.Group className="mb-3" controlId="formBasicPassword">
        <Form.Label>Confirm Password</Form.Label>
        <Form.Control type="password" placeholder="Enter Your Password Again" />
      </Form.Group>
     <Link to={'/Citizen_portal'}><Button  className="mb-5" variant="primary" type="submit">
        
     Sign Up</Button></Link>
      
    </Form>
      </div>
      <Footer/>
    </div>
  )
}

export default Signup