import React from 'react'
import './styles/Navbar.css'
import './styles/home.css'
import {Link} from 'react-router-dom'
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import 'bootstrap/dist/css/bootstrap.min.css';
import {AiOutlineCloseCircle} from 'react-icons/ai'
import Navbaar from './Navbar';




const Home = () => {

 
  return (
    <>
    
    <section className='signup'>
   
    <div className="d-grid gap-2">
     <form action="/home" method="POST">
      <h5 className='Designation-title'>Choose Your Designation:</h5>
      <select className="Designation" name="role" id="">
        <option className="Designation-opt" name="citizen" value="citizen">Citizen</option>
        <option className="Designation-opt" name="police" value="police">Police</option>
        <option className="Designation-opt" selected name="admin" value="admin">Admin</option>
      </select>
      <input name="email" class="form-control" type="text" placeholder="Enter Your Email"></input>
      <input name="passw" class="form-control" type="text" placeholder="Enter Password"></input>
      <h6 for="Designation">Enter Your Email:</h6>
      <Form.Control type="email" placeholder="Enter Your Email" />
      <h6 for="Designation">Enter Your Password:</h6>
      <Form.Control type="email" placeholder="Enter Your Password" />
      <Link to={'/Citizen_portal'}><Button type="submit"  variant="primary" size="lg">
        Log In
      </Button></Link>
      </form>
      <small className='small-txt'>Not yet Registered?<Link to={'/signup'} className='sign-up'>Sign Up</Link></small> 
    </div>
    
    
    <br></br>
    
    <h4>Things you should NOT do:</h4>
    <ul>
            <li>Never file a false complaint or give wrong information to the police. You can be
            prosecuted under law for giving wrong information or for misleading the police
            (Section 182 of the Pakistan Penal Code, 1860).</li>
            <li>Never exaggerate or distort facts.</li>
            <li> Never make vague or unclear statements.</li>
            <li>One who refuses to sign his statement of FIR can be prosecuted under section 180
            of Pakistan Penal Code, 1860.</li>
            <li>One who lodges a false charge of offence made with intent to injure a person can
            be prosecuted under section 211 of Pakistan Penal Code, 1860.</li>
    </ul>
  </section>
  </>
  )
}

export default Home