import React from 'react'
import {FaFacebookSquare} from "react-icons/fa";
import {FaTwitterSquare} from "react-icons/fa"
import {BsGithub} from "react-icons/bs"
import {FaInstagram} from "react-icons/fa"
import '../components/Footer.css'


const Footer = () => {
    
  return (

    
    <>

    <div className="container">
  <footer className="d-flex flex-wrap justify-content-between align-items-center py-3 my-4 border-top">
    <div className="col-md-4 d-flex align-items-center">
      <a href="/" className="mb-3 me-2 mb-md-0  text-decoration-none lh-1">
        <svg className="bi" width="30" height="24"><use href="#bootstrap"/></svg>
      </a>
      <span className="mb-3 mb-md-0 ">&copy; 2022 Company, Inc </span>
    </div>

    <ul className="nav col-md-6 justify-content-end list-unstyled d-flex">
      <li className="ms-3"><a className="icon" href="#"><FaFacebookSquare/></a></li>
      <li className="ms-3"><a className="icon" href="#"><FaTwitterSquare/></a></li>
      <li className="ms-3"><a className="icon" href="#"><FaInstagram/></a></li>
      <li className="ms-3"><a className="icon" href="#"><BsGithub/></a></li>
    </ul>
  </footer>
</div>
    </>
  )
}

export default Footer