import React from 'react'
import {Link} from 'react-router-dom'
import './styles/Navbar.css'
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import Admin from './Admin/Admin';
import logo from '../assets/logoo.png';


const Navbaar = () => {
  return (
    <div className="fluid">
    <div className='Navbaar'>
    <Container className='container-title'>
    <Navbar.Brand href="#home">
            <img
              src={logo}
              className="d-inline-block align-top logo"
              alt="React Bootstrap logo"
            />
          </Navbar.Brand>
      <Link to={'/'} class="nav-title mt-4" >Secure FIR Registeration System</Link>
      <ul className='nav-nav-navs'>
        <li><Link to={'/'} class="nav-navs" >Home</Link></li>
        <li><Link to={'/Admin'} class="nav-navs" >Complaints</Link></li>
        <li><Link to={'/'} class="nav-navs" >Statics</Link></li>
        <li><Link to={'/'} class="nav-navs" >About Us</Link></li>

      </ul>
      
    </Container>
  </div>

  </div>

    
  )
}

export default Navbaar