import React from 'react'
import Navbaar from '../components/Navbar'
import '../../src/citizen_portal.css'
import {AiOutlineCaretRight} from 'react-icons/ai';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import { Link } from 'react-router-dom';
import Footer from '../components/Footer';


const View_c_status = () => {
  return (
    <>
    
     

        <Navbaar/>
        < div className='container'>
        

         <div class="col-md-3 col-lg-2 sidebar-offcanvas pl-0" id="sidebar" role="navigation" style={{backgroundColor:"#e9ecef"}}>
            <ul class="nav flex-column sticky-top pl-0 pt-5 p-3 mt-3 ">
                <li class="nav-item mb-2 mt-3"><a class="nav-link text-primary" href="#"><h5>Citizen Portal</h5></a></li>
                <li  class="nav-item mb-2 "><Link class="nav-link text-dark" to={'/file_complaint'}><i class="fas fa-user font-weight-bold"></i>  <span className="ml-3"><AiOutlineCaretRight className='dash-icon'/> File A Complaint </span></Link></li>
                <li class="nav-item mb-2 "><a class="nav-link text-dark" href="#"><i class="fas fa-user font-weight-bold"></i> <span className="ml-3"><AiOutlineCaretRight className='dash-icon'/>View FIR</span></a></li>
                <li class="nav-item mb-2 "><a class="nav-link text-dark" href="#"><i class="fas fa-user font-weight-bold"></i> <span className="ml-3"><AiOutlineCaretRight className='dash-icon'/>View FIR Status</span></a></li>
                <li class="nav-item mb-2 "><a class="nav-link text-dark" href="#"><i class="fas fa-user font-weight-bold"></i> <span className="ml-3"><AiOutlineCaretRight className='dash-icon'/>View Complaint Status</span></a></li>
                <li class="nav-item mb-2 "><a class="nav-link text-dark" href="#"><i class="fas fa-user font-weight-bold"></i> <span className="ml-3"><AiOutlineCaretRight className='dash-icon'/>Reviews</span></a></li>
                <li class="nav-item mb-2 "><a class="nav-link text-dark" href="#"><i class="fas fa-user font-weight-bold"></i> <span className="ml-3"><AiOutlineCaretRight className='dash-icon'/>Response</span></a></li>
                <li class="nav-item mb-2 "><a class="nav-link text-dark" href="#"><i class="fas fa-user font-weight-bold"></i> <span className="ml-3"><AiOutlineCaretRight className='dash-icon'/>Log Out</span></a></li>
                
            </ul>
            
      
       </div>
       
       </div>
       <Footer/>
    </>
    
  )
}

export default View_c_status